#ifndef MY_STRING_H
#define MY_STRING_H

int getLength(char a[]);
void copyString(char dest[], char src[]);
int compareString(char str1[], char str2[]);
void concatenateString(char str1[], char str2[]);
void displayString(char str[]); 

#endif

