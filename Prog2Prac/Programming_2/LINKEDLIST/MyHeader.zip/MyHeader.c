#include <stdio.h>
#include <stdlib.h>
#include "MyHeader.h"

void insertFront(NodePtr *list, int item)
{
	NodePtr temp = malloc(sizeof(NodeType));
	
	if(temp != NULL)
	{
		temp->data = item;
		temp->next = *list;
		*list = temp;
	}
}
void display(NodePtr list)
{

	printf("{");
	while(list != NULL)
	{
		printf("%d", list->data);
		while (list->next != NULL)
		{
			printf("->%d", list->data);
			list = list->next;
		}
		list = list->next;
	}
	printf("}\n");
}
int getSum(NodePtr list)
{
	int sum = 0;
	while(list != NULL)
	{
		sum += list->data;
		list = list->next;
	}
	return sum;
}
float getAverage(NodePtr list)
{
	float sum = 0; 
	int count = 0;
	
	while(list != NULL)
	{
		count++;
		sum += list->data;
		list = list->next;
	}
	
	return sum/count;
	
}
int countFactors(NodePtr list, int value)
{
	int count = 0;
	while(list != NULL)
	{
		if((list->data % value) == 0)
		{
			count++;
		}
		list = list->next;
	}
	return count;
}

void doubleOddNumbers(NodePtr list)
{
	while(list != NULL)
	{
		if((list->data % 2) != 0)
		{
			list->data * 2;
		}
		list = list->next;
	}
}

